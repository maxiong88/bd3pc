<?php

$page = $_REQUEST['page'];
if($page == '1'){
    $a = '{
        "status" : 1,
        "page" : 1,
        "pageSize" : 20,
        "totalPage" : 6,
        "total" : 10,
        "data":[{
            "id" : 1,
            "articleImg" : "./static/img/mark-3.jpg",
            "author" : "累到·轨道1",
            "time" : "2000-00-00",
            "articleMsg" : "我就是我怕我就是我怕我就是我怕我就是我怕我就是我怕我就是我怕我就是我怕我就是我怕我就是我怕我就是我怕我就是我怕我就是我怕",
            "articleTit" : "我就是我怕我就是我怕我就是我怕我就是我怕我就是我怕我就是我怕"
        },{
            "id" : 1,
            "articleImg" : "./upload/IMG_0231.png",
            "author" : "累到·轨道1",
            "time" : "2000-00-00",
            "articleMsg" : "我就是我怕我就是我怕我就是我怕我就是我怕我就是我怕我就是我怕我就是我怕我就是我怕我就是我怕我就是我怕我就是我怕我就是我怕",
            "articleTit" : "我就是我怕我就是我怕我就是我怕我就是我怕我就是我怕我就是我怕"
        }]
    }';
}else if($page == '2'){
    $a = '{
        "status" : 1,
        "page" : 2,
        "pageSize" : 20,
        "totalPage" : 6,
        "total" : 10,
        "data":[{
            "id" : 1,
            "articleImg" : "./upload/IMG_0231.png",
            "author" : "累到·轨道1",
            "time" : "2000-00-00",
            "articleMsg" : "我就是我怕我就是我怕我就是我怕我就是我怕我就是我怕我就是我怕我就是我怕我就是我怕我就是我怕我就是我怕我就是我怕我就是我怕",
            "articleTit" : "我就是我怕我就是我怕我就是我怕我就是我怕我就是我怕我就是我怕"
        }]
    }';
}else if($page == '3'){
    $a = '{
        "status" : 1,
        "page" : 3,
        "pageSize" : 20,
        "totalPage" : 6,
        "total" : 10,
        "data":[{
            "id" : 1,
            "articleImg" : "./upload/IMG_0231.png",
            "author" : "累到·轨道1",
            "time" : "2000-00-00",
            "articleMsg" : "我就是我怕我就是我怕我就是我怕我就是我怕我就是我怕我就是我怕我就是我怕我就是我怕我就是我怕我就是我怕我就是我怕我就是我怕",
            "articleTit" : "我就是我怕我就是我怕我就是我怕我就是我怕我就是我怕我就是我怕"
        },{
            "id" : 1,
            "articleImg" : "./upload/IMG_0231.png",
            "author" : "累到·轨道1",
            "time" : "2000-00-00",
            "articleMsg" : "我就是我怕我就是我怕我就是我怕我就是我怕我就是我怕我就是我怕我就是我怕我就是我怕我就是我怕我就是我怕我就是我怕我就是我怕",
            "articleTit" : "我就是我怕我就是我怕我就是我怕我就是我怕我就是我怕我就是我怕"
        }]
    }';
}else if($page == '4'){
    $a = '{
        "status" : 1,
        "page" : 4,
        "pageSize" : 20,
        "totalPage" : 6,
        "total" : 10,
        "data":[{
            "id" : 1,
            "articleImg" : "./upload/IMG_0231.png",
            "author" : "累到·轨道1",
            "time" : "2000-00-00",
            "articleMsg" : "我就是我怕我就是我怕我就是我怕我就是我怕我就是我怕我就是我怕我就是我怕我就是我怕我就是我怕我就是我怕我就是我怕我就是我怕",
            "articleTit" : "我就是我怕我就是我怕我就是我怕我就是我怕我就是我怕我就是我怕"
        }]
    }';
}else if($page == '5'){
    $a = '{
        "status" : 1,
        "page" : 5,
        "pageSize" : 20,
        "totalPage" : 6,
        "total" : 10,
        "data":[{
            "id" : 1,
            "articleImg" : "./upload/IMG_0231.png",
            "author" : "累到·轨道1",
            "time" : "2000-00-00",
            "articleMsg" : "我就是我怕我就是我怕我就是我怕我就是我怕我就是我怕我就是我怕我就是我怕我就是我怕我就是我怕我就是我怕我就是我怕我就是我怕",
            "articleTit" : "我就是我怕我就是我怕我就是我怕我就是我怕我就是我怕我就是我怕"
        },{
            "id" : 1,
            "articleImg" : "./upload/IMG_0231.png",
            "author" : "累到·轨道1",
            "time" : "2000-00-00",
            "articleMsg" : "我就是我怕我就是我怕我就是我怕我就是我怕我就是我怕我就是我怕我就是我怕我就是我怕我就是我怕我就是我怕我就是我怕我就是我怕",
            "articleTit" : "我就是我怕我就是我怕我就是我怕我就是我怕我就是我怕我就是我怕"
        }]
    }';
}else if($page == '6'){
    $a = '{
        "status" : 1,
        "page" : 6,
        "pageSize" : 20,
        "totalPage" : 6,
        "total" : 10,
        "data":[{
            "id" : 1,
            "articleImg" : "./upload/IMG_0231.png",
            "author" : "累到·轨道1",
            "time" : "2000-00-00",
            "articleMsg" : "我就是我怕我就是我怕我就是我怕我就是我怕我就是我怕我就是我怕我就是我怕我就是我怕我就是我怕我就是我怕我就是我怕我就是我怕",
            "articleTit" : "我就是我怕我就是我怕我就是我怕我就是我怕我就是我怕我就是我怕"
        },{
            "id" : 1,
            "articleImg" : "./upload/IMG_0231.png",
            "author" : "累到·轨道1",
            "time" : "2000-00-00",
            "articleMsg" : "我就是我怕我就是我怕我就是我怕我就是我怕我就是我怕我就是我怕我就是我怕我就是我怕我就是我怕我就是我怕我就是我怕我就是我怕",
            "articleTit" : "我就是我怕我就是我怕我就是我怕我就是我怕我就是我怕我就是我怕"
        }]
    }';
}

echo json_decode(json_encode($a));

?>