<?php

$page = $_REQUEST['page'];
if($page == '1'){
    $a = '{
        "status" : 1,
        "page" : 1,
        "pageSize" : 20,
        "totalPage" : 2,
        "total" : 2,
        "data":[{
            "id" : 1,
            "info_msg" : "设置为 true 以在浏览器开发工具的性能/时间线面板中启用对组件初始化、编译、渲染和打补丁的性能追踪。只适用于开发模式和支持 performance.mark API 的浏览器上。",
            "info_url" : "./article-list.html",
            "info_author" : "的挥洒的",
            "info_time" : "2090-09-99"
        },{
            "id" : 2,
            "info_msg" : "设置为 true 以在浏览器开发工具的性能/时间线面板中启用对组件初始化、编译、渲染和打补丁的性能追踪。只适用于开发模式和支持 performance.mark API 的浏览器上。",
            "info_url" : "./article-list.html",
            "info_author" : "的挥洒的",
            "info_time" : "2090-09-99"
        },{
            "id" : 1,
            "info_msg" : "设置为 true 以在浏览器开发工具的性能/时间线面板中启用对组件初始化、编译、渲染和打补丁的性能追踪。只适用于开发模式和支持 performance.mark API 的浏览器上。",
            "info_url" : "./article-list.html",

            "info_author" : "的挥洒的",
            "info_time" : "2090-09-99"
        },{
            "id" : 2,
            "info_msg" : "设置为 true 以在浏览器开发工具的性能/时间线面板中启用对组件初始化、编译、渲染和打补丁的性能追踪。只适用于开发模式和支持 performance.mark API 的浏览器上。",
            "info_url" : "./article-list.html",
            "info_author" : "的挥洒的",
            "info_time" : "2090-09-99"
        },{
            "id" : 1,
            "info_msg" : "设置为 true 以在浏览器开发工具的性能/时间线面板中启用对组件初始化、编译、渲染和打补丁的性能追踪。只适用于开发模式和支持 performance.mark API 的浏览器上。",
            "info_url" : "./article-list.html",
            "info_author" : "的挥洒的",
            "info_time" : "2090-09-99"
        },{
            "id" : 2,
            "info_msg" : "设置为 true 以在浏览器开发工具的性能/时间线面板中启用对组件初始化、编译、渲染和打补丁的性能追踪。只适用于开发模式和支持 performance.mark API 的浏览器上。",
            "info_url" : "./article-list.html",
            "info_author" : "的挥洒的",
            "info_time" : "2090-09-99"
        },{
            "id" : 1,
            "info_msg" : "设置为 true 以在浏览器开发工具的性能/时间线面板中启用对组件初始化、编译、渲染和打补丁的性能追踪。只适用于开发模式和支持 performance.mark API 的浏览器上。",
            "info_url" : "./article-list.html",
            "info_author" : "的挥洒的",
            "info_time" : "2090-09-99"
        },{
            "id" : 2,
            "info_msg" : "设置为 true 以在浏览器开发工具的性能/时间线面板中启用对组件初始化、编译、渲染和打补丁的性能追踪。只适用于开发模式和支持 performance.mark API 的浏览器上。",
            "info_url" : "./article-list.html",
            "info_author" : "的挥洒的",
            "info_time" : "2090-09-99"
        },{
            "id" : 1,
            "info_msg" : "设置为 true 以在浏览器开发工具的性能/时间线面板中启用对组件初始化、编译、渲染和打补丁的性能追踪。只适用于开发模式和支持 performance.mark API 的浏览器上。",
            "info_url" : "./article-list.html",
            "info_author" : "的挥洒的",
            "info_time" : "2090-09-99"
        },{
            "id" : 2,
            "info_msg" : "设置为 true 以在浏览器开发工具的性能/时间线面板中启用对组件初始化、编译、渲染和打补丁的性能追踪。只适用于开发模式和支持 performance.mark API 的浏览器上。",
            "info_url" : "./article-list.html",
            "info_author" : "的挥洒的",
            "info_time" : "2090-09-99"
        },{
            "id" : 1,
            "info_msg" : "设置为 true 以在浏览器开发工具的性能/时间线面板中启用对组件初始化、编译、渲染和打补丁的性能追踪。只适用于开发模式和支持 performance.mark API 的浏览器上。",
            "info_url" : "./article-list.html",
            "info_author" : "的挥洒的",
            "info_time" : "2090-09-99"
        },{
            "id" : 2,
            "info_msg" : "设置为 true 以在浏览器开发工具的性能/时间线面板中启用对组件初始化、编译、渲染和打补丁的性能追踪。只适用于开发模式和支持 performance.mark API 的浏览器上。",
            "info_url" : "./article-list.html",
            "info_author" : "的挥洒的",
            "info_time" : "2090-09-99"
        },{
            "id" : 1,
            "info_msg" : "设置为 true 以在浏览器开发工具的性能/时间线面板中启用对组件初始化、编译、渲染和打补丁的性能追踪。只适用于开发模式和支持 performance.mark API 的浏览器上。",
            "info_url" : "./article-list.html",
            "info_time" : "2090-09-99"
        },{
            "id" : 2,
            "info_msg" : "设置为 true 以在浏览器开发工具的性能/时间线面板中启用对组件初始化、编译、渲染和打补丁的性能追踪。只适用于开发模式和支持 performance.mark API 的浏览器上。",
            "info_url" : "./article-list.html",
            "info_author" : "的挥洒的",
            "info_time" : "2090-09-99"
        },{
            "id" : 1,
            "info_msg" : "设置为 true 以在浏览器开发工具的性能/时间线面板中启用对组件初始化、编译、渲染和打补丁的性能追踪。只适用于开发模式和支持 performance.mark API 的浏览器上。",
            "info_url" : "./article-list.html",
            "info_author" : "的挥洒的",
            "info_time" : "2090-09-99"
        },{
            "id" : 2,
            "info_msg" : "设置为 true 以在浏览器开发工具的性能/时间线面板中启用对组件初始化、编译、渲染和打补丁的性能追踪。只适用于开发模式和支持 performance.mark API 的浏览器上。",
            "info_url" : "./article-list.html",
            "info_author" : "的挥洒的",
            "info_time" : "2090-09-99"
        }]
    }';
}else if($page == '2'){
    $a = '{
        "status" : 1,
        "page" : 2,
        "pageSize" : 20,
        "totalPage" : 2,
        "total" : 2,
        "data":[{
            "id" : 1,
            "info_msg" : "设置为 true 以在浏览器开发工具的性能/时间线面板中启用对组件初始化、编译、渲染和打补丁的性能追踪。只适用于开发模式和支持 performance.mark API 的浏览器上。",
            "info_url" : "./article-list.html",
            "info_author" : "的挥洒的",
            "info_time" : "2090-09-99"
        },{
            "id" : 2,
            "info_msg" : "1设置为 true 以在浏览器开发工具的性能/时间线面板中启用对组件初始化、编译、渲染和打补丁的性能追踪。只适用于开发模式和支持 performance.mark API 的浏览器上。",
            "info_url" : "./article-list.html",
            "info_author" : "的挥洒的",
            "info_time" : "2090-09-99"
        },{
            "id" : 1,
            "info_msg" : "设置为 true 以在浏览器开发工具的性能/时间线面板中启用对组件初始化、编译、渲染和打补丁的性能追踪。只适用于开发模式和支持 performance.mark API 的浏览器上。",
            "info_url" : "./article-list.html",
            "info_author" : "的挥洒的",
            "info_time" : "2090-09-99"
        },{
            "id" : 2,
            "info_msg" : "设置为 true 以在浏览器开发工具的性能/时间线面板中启用对组件初始化、编译、渲染和打补丁的性能追踪。只适用于开发模式和支持 performance.mark API 的浏览器上。",
            "info_url" : "./article-list.html",
            "info_author" : "的挥洒的",
            "info_time" : "2090-09-99"
        },{
            "id" : 1,
            "info_msg" : "设置为 true 以在浏览器开发工具的性能/时间线面板中启用对组件初始化、编译、渲染和打补丁的性能追踪。只适用于开发模式和支持 performance.mark API 的浏览器上。",
            "info_url" : "./article-list.html",
            "info_author" : "的挥洒的",
            "info_time" : "2090-09-99"
        },{
            "id" : 2,
            "info_msg" : "设置为 true 以在浏览器开发工具的性能/时间线面板中启用对组件初始化、编译、渲染和打补丁的性能追踪。只适用于开发模式和支持 performance.mark API 的浏览器上。",
            "info_url" : "./article-list.html",
            "info_author" : "的挥洒的",
            "info_time" : "2090-09-99"
        },{
            "id" : 1,
            "info_msg" : "设置为 true 以在浏览器开发工具的性能/时间线面板中启用对组件初始化、编译、渲染和打补丁的性能追踪。只适用于开发模式和支持 performance.mark API 的浏览器上。",
            "info_url" : "./article-list.html",
            "info_author" : "的挥洒的",
            "info_time" : "2090-09-99"
        },{
            "id" : 2,
            "info_msg" : "设置为 true 以在浏览器开发工具的性能/时间线面板中启用对组件初始化、编译、渲染和打补丁的性能追踪。只适用于开发模式和支持 performance.mark API 的浏览器上。",
            "info_url" : "./article-list.html",
            "info_time" : "2090-09-99"
        },{
            "id" : 1,
            "info_msg" : "设置为 true 以在浏览器开发工具的性能/时间线面板中启用对组件初始化、编译、渲染和打补丁的性能追踪。只适用于开发模式和支持 performance.mark API 的浏览器上。",
            "info_url" : "./article-list.html",
            "info_author" : "的挥洒的",
            "info_time" : "2090-09-99"
        },{
            "id" : 2,
            "info_msg" : "设置为 true 以在浏览器开发工具的性能/时间线面板中启用对组件初始化、编译、渲染和打补丁的性能追踪。只适用于开发模式和支持 performance.mark API 的浏览器上。",
            "info_url" : "./article-list.html",
            "info_author" : "的挥洒的",
            "info_time" : "2090-09-99"
        },{
            "id" : 1,
            "info_msg" : "设置为 true 以在浏览器开发工具的性能/时间线面板中启用对组件初始化、编译、渲染和打补丁的性能追踪。只适用于开发模式和支持 performance.mark API 的浏览器上。",
            "info_url" : "./article-list.html",
            "info_author" : "的挥洒的",
            "info_time" : "2090-09-99"
        },{
            "id" : 2,
            "info_msg" : "设置为 true 以在浏览器开发工具的性能/时间线面板中启用对组件初始化、编译、渲染和打补丁的性能追踪。只适用于开发模式和支持 performance.mark API 的浏览器上。",
            "info_url" : "./article-list.html",
            "info_author" : "的挥洒的",
            "info_time" : "2090-09-99"
        },{
            "id" : 1,
            "info_msg" : "设置为 true 以在浏览器开发工具的性能/时间线面板中启用对组件初始化、编译、渲染和打补丁的性能追踪。只适用于开发模式和支持 performance.mark API 的浏览器上。",
            "info_url" : "./article-list.html",
            "info_author" : "的挥洒的",
            "info_time" : "2090-09-99"
        },{
            "id" : 2,
            "info_msg" : "设置为 true 以在浏览器开发工具的性能/时间线面板中启用对组件初始化、编译、渲染和打补丁的性能追踪。只适用于开发模式和支持 performance.mark API 的浏览器上。",
            "info_url" : "./article-list.html",
            "info_author" : "的挥洒的",
            "info_time" : "2090-09-99"
        },{
            "id" : 1,
            "info_msg" : "设置为 true 以在浏览器开发工具的性能/时间线面板中启用对组件初始化、编译、渲染和打补丁的性能追踪。只适用于开发模式和支持 performance.mark API 的浏览器上。",
            "info_url" : "./article-list.html",
            "info_author" : "的挥洒的",
            "info_time" : "2090-09-99"
        },{
            "id" : 2,
            "info_msg" : "设置为 true 以在浏览器开发工具的性能/时间线面板中启用对组件初始化、编译、渲染和打补丁的性能追踪。只适用于开发模式和支持 performance.mark API 的浏览器上。",
            "info_url" : "./article-list.html",
            "info_author" : "的挥洒的",
            "info_time" : "2090-09-99"
        }]
    }';
}

echo json_decode(json_encode($a));

?>