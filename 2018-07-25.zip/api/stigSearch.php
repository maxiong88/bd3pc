<?php 

$a = '{
    "status" : 1,
    "message" : "暂未开放",
    "data" : [{

    }]
}';

echo json_decode(json_encode($a))

?>